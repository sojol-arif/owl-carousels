//---------------------=================pre loader=====================--------------------------

  
  
  
  
  
  
    window.addEventListener('DOMContentLoaded', function() {
        new QueryLoader2(document.querySelector(".load"), {
            barColor: "#efefef",
            backgroundColor: "#111",
            percentage: true,
            barHeight: 1,
            minimumTime: 200,
            fadeOutTime: 1000
        });
    });






//----------==============-----------owl-carosol area-------================-------------------

$(document).ready(function(){
	 $('.carousel-list').owlCarousel({
		loop:true,
		margin:10,
		responsiveClass:true,
		responsive:{
			0:{
				items:1,
				nav:true
			},
			
			600:{
				items:1,
				nav:false
			},
			1000:{
				items:1,
				nav:true,
				loop:false
			}
		}
	});
});

$(document).ready(function(){
	 
	 
	 $('.carousel-list-2').owlCarousel({
		loop:true,
		margin:10,
		dots: false,
		nav: false,
		responsiveClass:true,
		responsive:{
			0:{
				items:1,
			},
			
			600:{
				items:1,
			},
			1000:{
				items:1,
				loop:false
			}
		}
	});

});


//----------==============-----------scroll-top area-------================-------------------

$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {

    // Prevent default anchor click behavior
    event.preventDefault();

    // Store hash
    var hash = this.hash;

    // Using jQuery's animate() method to add smooth page scroll
    // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
    $('html, body').animate({
      scrollTop: $(hash).offset().top
    }, 900, function(){
   
      // Add hash (#) to URL when done scrolling (default click behavior)
      window.location.hash = hash;
    });
  });
  
  $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
});












//----------==============-----------wow-animate area-------================-------------------




    wow = new WOW(
      {
        animateClass: 'animated',
        offset:       100,
        callback:     function(box) {
          console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
        }
      }
    );
    wow.init();
    document.getElementById('moar').onclick = function() {
      var section = document.createElement('section');
      section.className = 'section--purple wow fadeInDown';
      this.parentNode.insertBefore(section, this);
    };

	
	
